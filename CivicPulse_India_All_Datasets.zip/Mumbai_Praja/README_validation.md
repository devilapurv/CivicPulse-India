# CivicPulse India — Phase 1 Data Dictionary and Validation

## Source
Praja Foundation, *Report on the Status of Civic Issues in Mumbai*, May 2025.
Source: user-supplied PDF. Page numbers below are PDF page numbers (printed report pages are one lower).

## Extracted files
| File | Source | Grain |
|---|---|---|
| 01_issue_history_2015_2024.csv | Table 43, PDF p.71 | one complaint type per year |
| 02_issue_resolution_2023_2024.csv | Table 44, PDF p.72 | one complaint type, comparing 2023 and 2024; TOTAL row included |
| 03_ward_resolution_2023_2024.csv | Table 45, PDF p.73 | one ward, comparing 2023 and 2024; TOTAL row included |
| 04_escalation_history_2020_2024.csv | Table 46, PDF p.75 | one year |
| 05_ward_history_2015_2024.csv | Table 53, PDF p.86 | one ward per year |
| 06_issue_escalations_2024.csv | Table 55, PDF p.88 | one complaint type in 2024 |
| 07_ward_escalations_2024.csv | Table 55, PDF p.89 | one ward in 2024 |

## Important column meanings
- `complaints_received` / `received_2024`: reported number of complaints.
- `closed_2024`: complaints reported closed in 2024.
- `closed_pct_reported_2024`: the **printed** whole-number percentage, not a recomputed precise rate.
- `avg_resolution_days_2024`: reported average days to close complaints; it is an aggregate.
- `escalated_level1_2024`, etc.: escalated complaint counts at the corresponding level.
- `population_2024_reported`: 2024 ward population figure printed in the source (repeated across historical ward-year rows for convenience); **not** annual population.
- `source_table`: the original report table number.

## Validation results
- 2024 issue history total: 115,396.
- 2024 ward history total: 115,396.
- 2024 issue resolution total: 115,396.
- 2024 ward resolution total: 115,396.
- 2024 issue escalation total: 115,396.
- 2024 ward escalation total: 115,396.
- 2024 Level I escalation total: 23,490 in both issue and ward breakdowns.
- 2024 reported closed count: 88,308, approximately 77%.
- The issue history has one missing 2015 value (category 'Nuisance due to vagrants/ stray Dogs, monkey') because the source prints a dash. This is missing, **not zero**.
- Printed closure percentages are rounded. One 2023 issue-level printed percentage differs from the calculated ratio by about 0.63 percentage points; retained as printed.
- **Source discrepancy:** Table 53's printed 2015 total is 67,835, but its 24 ward rows sum to 67,773, matching Table 43's 2015 total (67,773). No value was altered to force the printed total.
- Table 44/45 'TOTAL' rows must be excluded from per-category/per-ward aggregation to avoid double counting.
- The report has some inconsistent narrative descriptions and printed values; CSVs follow the numerical tables rather than silently correcting them.

## Model feasibility
These are **aggregate** records, not individual complaint cases. Do not train a model to predict an individual complaint's resolution time from this dataset alone.
With only ten annual observations per category/ward, treat forecasts as experimental; compare with simple baseline forecasts and evaluate on held-out years.
Ward-level and category-level totals are separate dimensions; **do not** join them on year to infer ward × category counts.
Table 55 has two separate breakdowns, by issue and by ward, not a joint ward-by-issue matrix.

## How to start
1. Unzip the folder and open it in Google Colab or Jupyter.
2. Upload `01_issue_history_2015_2024.csv`.
3. Run the beginner-friendly code in `beginner_analysis.py`, one block at a time.
4. The source PDF should be credited in any published repository. Check Praja Foundation's terms before redistributing extracted data.
